#!/bin/bash
#!/bin/bash

# L92 Shop Stock Alert - Helper Functions

DATA_FILE="data/stock.csv"
LOG_FILE="logs/activity.log"
BACKUP_DIR="backups"


# 1. Log activity
log() {
    local message="$1"

    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $message" | tee -a "$LOG_FILE"
}


# 2. Check whether stock data exists
check_data() {
    if [[ ! -f "$DATA_FILE" ]]; then
        echo "Error: Stock data file not found!"
        return 1
    fi

    if ! head -n 1 "$DATA_FILE" | grep -qx "item,qty,reorder_level,price"; then
        echo "Error: CSV header is incorrect!"
        return 1
    fi

    return 0
}


# 3. Display help information
show_help() {
    echo "================================"
    echo "       SHOP STOCK ALERT"
    echo "================================"
    echo "Usage: ./main.sh [option]"
    echo ""
    echo "Options:"
    echo "  --help     Display help information"
    echo "  --backup   Back up stock data"
    echo "  --cron     Generate reorder report"
    echo ""
}


# 4. View all stock
view_data() {
    if ! check_data; then
        return 1
    fi

    echo "========== STOCK DETAILS =========="

    awk -F, '{
        printf "%-18s %-10s %-15s %-12s\n", $1, $2, $3, $4
    }' "$DATA_FILE"
}


# 5. Create stock backup
do_backup() {
    if ! check_data; then
        return 1
    fi

    mkdir -p "$BACKUP_DIR"

    local backup_file="$BACKUP_DIR/stock_$(date '+%Y%m%d_%H%M%S').csv"

    if cp "$DATA_FILE" "$backup_file"; then
        echo "Backup created: $backup_file"
        log "Stock data backup created: $backup_file"
    else
        echo "Error: Backup failed!"
        return 1
    fi
}


# 6. View activity log
view_log() {
    if [[ -f "$LOG_FILE" ]]; then
        echo "========== ACTIVITY LOG =========="
        cat "$LOG_FILE"
    else
        echo "No activity log found yet."
    fi
}
# 7. Sell an item
sell_item() {

    if ! check_data; then
        return 1
    fi

    echo "========== SELL ITEM =========="

    read -r -p "Enter product name: " item

    if [[ -z "$item" ]]; then
        echo "Error: Product name cannot be empty!"
        return 1
    fi

    # Find current stock quantity
    current_qty=$(awk -F, -v item="$item" \
        '$1 == item {print $2; found=1}
        END {if (!found) exit 1}' "$DATA_FILE")

    if [[ $? -ne 0 ]]; then
        echo "Error: Product not found!"
        return 1
    fi

    read -r -p "Enter quantity to sell: " quantity

    # Validate quantity
    if ! [[ "$quantity" =~ ^[0-9]+$ ]] || (( 10#$quantity <= 0 )); then
        echo "Error: Enter a valid positive quantity!"
        return 1
    fi

    if (( 10#$quantity > 10#$current_qty )); then
        echo "Error: Not enough stock available!"
        echo "Available stock: $current_qty"
        return 1
    fi

    # Update stock using awk
    awk -F, -v OFS=, -v item="$item" -v sold="$quantity" '
        NR == 1 {print; next}
        $1 == item {$2 = $2 - sold}
        {print}
    ' "$DATA_FILE" > "$DATA_FILE.tmp" && mv "$DATA_FILE.tmp" "$DATA_FILE"

    if [[ $? -eq 0 ]]; then
        echo "Sale successful!"
        echo "Product: $item"
        echo "Quantity sold: $quantity"
        echo "Remaining stock: $((10#$current_qty - 10#$quantity))"

        log "Sold $quantity units of $item"
    else
        echo "Error: Could not update stock!"
        return 1
    fi
}
# 8. Add stock
add_stock() {

    if ! check_data; then
        return 1
    fi

    echo "========== ADD STOCK =========="

    read -r -p "Enter product name: " item

    if [[ -z "$item" ]]; then
        echo "Error: Product name cannot be empty!"
        return 1
    fi

    # Check whether product exists
    current_qty=$(awk -F, -v item="$item" \
        '$1 == item {print $2; found=1}
        END {if (!found) exit 1}' "$DATA_FILE")

    if [[ $? -ne 0 ]]; then
        echo "Error: Product not found!"
        return 1
    fi

    read -r -p "Enter quantity to add: " quantity

    # Validate quantity
    if ! [[ "$quantity" =~ ^[0-9]+$ ]] || (( 10#$quantity <= 0 )); then
        echo "Error: Enter a valid positive quantity!"
        return 1
    fi

    new_qty=$((10#$current_qty + 10#$quantity))

    # Update CSV file
    awk -F, -v OFS=, -v item="$item" -v new_qty="$new_qty" '
        NR == 1 {print; next}
        $1 == item {$2 = new_qty}
        {print}
    ' "$DATA_FILE" > "$DATA_FILE.tmp" && mv "$DATA_FILE.tmp" "$DATA_FILE"

    if [[ $? -eq 0 ]]; then
        echo "Stock added successfully!"
        echo "Product: $item"
        echo "Previous stock: $current_qty"
        echo "Added quantity: $quantity"
        echo "New stock: $new_qty"

        log "Added $quantity units to $item"
    else
        echo "Error: Could not update stock!"
        return 1
    fi
}
# 9. View low stock items
low_stock() {

    if ! check_data; then
        return 1
    fi

    echo "========== LOW STOCK ITEMS =========="

    awk -F, '
        NR == 1 {next}
        $2 < $3 {
            printf "%-18s Quantity: %-8s Reorder Level: %s\n", $1, $2, $3
            found=1
        }
        END {
            if (!found) {
                print "No low stock items found."
            }
        }
    ' "$DATA_FILE"
}
# 10. Calculate total stock value
total_stock_value() {

    if ! check_data; then
        return 1
    fi

    echo "========== TOTAL STOCK VALUE =========="

    awk -F, '
        NR == 1 {next}
        {
            total = total + ($2 * $4)
        }
        END {
            printf "Total Stock Value: Rs. %.2f\n", total
        }
    ' "$DATA_FILE"
}
# 11. Generate reorder report
generate_reorder_report() {

    if ! check_data; then
        return 1
    fi

    mkdir -p reports

    # Create a dated report filename
    local report_file="${1:-reports/reorder_$(date '+%Y%m%d').txt}"

    {
        echo "======================================"
        echo "       SHOP REORDER REPORT"
        echo "======================================"
        echo "Generated on: $(date '+%Y-%m-%d %H:%M:%S')"
        echo ""
        echo "Products requiring reorder:"
        echo "--------------------------------------"

        awk -F, '
            NR == 1 {next}
            $2 < $3 {
                printf "Item: %-18s Quantity: %-8s Reorder Level: %s\n", $1, $2, $3
                found=1
            }
            END {
                if (!found) {
                    print "No products require reorder."
                }
            }
        ' "$DATA_FILE"

        echo "======================================"

    } > "$report_file"

    if [[ $? -eq 0 ]]; then
        echo "Reorder report created successfully!"
        echo "Report location: $report_file"
        log "Reorder report created: $report_file"
    else
        echo "Error: Could not create reorder report!"
        return 1
    fi
}
