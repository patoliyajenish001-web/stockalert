#!/bin/bash
#!/bin/bash

# L92 Shop Stock Alert
# Main Program

# Load helper functions
source lib/functions.sh


# Command-line arguments
case "${1:-}" in

    --help)
        show_help
        exit 0
        ;;

    --backup)
        do_backup
        exit $?
        ;;

    --cron)
        generate_reorder_report "reports/reorder.txt"
        exit $?
        ;;

    "")
        # No argument: open main menu
        ;;

    *)
        echo "Invalid option: $1"
        echo "Use ./main.sh --help for instructions."
        exit 1
        ;;

esac


# Main menu
while true
do
    clear

    echo "================================"
    echo "       SHOP STOCK ALERT"
    echo "================================"
    echo "1. Sell Item"
    echo "2. Add Stock"
    echo "3. View Low Stock Items"
    echo "4. Calculate Total Stock Value"
    echo "5. Generate Reorder Report"
    echo "6. View All Stock"
    echo "7. Backup Stock Data"
    echo "8. View Activity Log"
    echo "0. Exit"
    echo "================================"

    read -r -p "Enter your choice: " choice

    case $choice in
        1)
            sell_item
            ;;
        2)
            add_stock
            ;;
        3)
            low_stock
            ;;
        4)
            total_stock_value
            ;;
        5)
            generate_reorder_report
            ;;
        6)
            view_data
            ;;
        7)
            do_backup
            ;;
        8)
            view_log
            ;;
        0)
            echo "Thank you for using Shop Stock Alert!"
            exit 0
            ;;
        *)
            echo "Invalid choice! Please try again."
            ;;
    esac

    read -r -p "Press Enter to continue..."
done
