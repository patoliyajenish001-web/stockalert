# L92 - Shop Stock Alert System

## Project Information
- Project Name: Shop Stock Alert System
- Student Name: PATOLIYA JENISH
- Roll Number: D63
- Division: H

## Project Description
Shop Stock Alert is a Linux Shell Script based inventory management
system. It helps users manage product stock, sell products, add stock,
identify low-stock products, calculate stock value, and generate
reorder reports.

## Features
1. Sell Item
2. Add Stock
3. Show Low Stock Products
4. Calculate Total Stock Value
5. Generate Reorder Report
6. View Stock Data
7. Create Backup
8. View Activity Log
0. Exit

## Project Structure
stockalert/
├── main.sh
├── README.md
├── lib/
│   └── functions.sh
├── data/
│   └── stock.csv
├── reports/
├── backups/
└── logs/

## Requirements
- Linux / Ubuntu / WSL
- Bash Shell
- AWK
- SED
- GREP
- SORT
- Cron

## How to Run
Open the terminal and go to the project directory:

    cd ~/linux_project/stockalert

Run the application:

    ./main.sh

Show help:

    ./main.sh --help

Create backup:

    ./main.sh --backup

Generate reorder report:

    ./main.sh --cron

## Automatic Reorder Report
The project uses Cron to generate a reorder report automatically
every day at 9:00 PM Indian Standard Time (IST).

Cron schedule:

    30 15 * * * cd /home/niv/linux_project/stockalert && /bin/bash ./main.sh --cron >> /home/niv/linux_project/stockalert/logs/cron.log 2>&1

Note: WSL must be running for the scheduled Cron job to execute.

## Data Format
The stock.csv file contains the following columns:

    item,qty,reorder_level,price

## Backup and Logs
- Backup files are stored in the backups/ directory.
- Activity logs are stored in logs/activity.log.
- Cron output is stored in logs/cron.log.
- Reorder reports are stored in the reports/ directory.

## Conclusion
The Shop Stock Alert System provides a simple way to manage shop
inventory using Linux shell scripting and automation.
